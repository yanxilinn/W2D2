require "employee"

class Startup
    def initialize(name, funding, salaries)
        @name = name
        @funding = funding 
        @salaries = salaries
        @employees = []
    end 

    def name 
        @name
    end 

    def funding 
        @funding 
    end 

    def salaries
        @salaries
    end 

    def employees
        @employees
    end 

    def valid_title?(title)
        @salaries.has_key?(title)
    end 

    def >(another_Startup)
        if self.funding > another_Startup.funding 
            return true
        else 
            false 
        end 
    end 

    def hire(employee_name, title)
        if self.valid_title?(title)
            @employees <<  Employee.new(employee_name, title)
        else 
            raise "error"
        end 
    end 

    def size
        @employees.length
    end 

    def pay_employee(employee)
        money = @salaries [employee.title]
        if @funding >= money
            employee.pay(money)
            @funding -= money
        else 
            raise "error"
        end 
    end 

    def payday
        @employees.each do |employee|
            self.pay_employee(employee)
        end 
    end 

    def average_salary
        sum = 0
        @employees.each do |employee|
            sum += @salaries [employee.title]
        end 

        sum / (@employees.length)
    end 

    def close
        @employees = []
        @funding = 0
    end 

    def acquire(another_Startup)
        @funding += another_Startup.funding
        another_Startup.salaries.each do |title, amount|
            if !@salaries.has_key?(title)
                @salaries[title] = amount
            end 
        end 
        @employees += another_Startup.employees
        another_Startup.close()
    end 
end
